

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="h3 mb-2 text-gray-800">Events</h1>
                <manage-event :events="<?php echo e(json_encode($events)); ?>" :companies="<?php echo e(json_encode($companies)); ?>"></manage-event>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffo\Documents\OP Docs\Projects\electionapp\resources\views/event/index.blade.php ENDPATH**/ ?>