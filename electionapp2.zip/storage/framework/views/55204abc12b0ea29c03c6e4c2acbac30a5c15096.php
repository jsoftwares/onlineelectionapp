

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- <h1 class="h3 mb-2 text-gray-800">Events</h1> -->
            <online-poll :event="<?php echo e(json_encode($event)); ?>"></online-poll>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffo\Documents\OP Docs\Projects\electionapp\resources\views/event/online_poll.blade.php ENDPATH**/ ?>