

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
            <result-screen :event="<?php echo e(json_encode($event)); ?>"></result-screen>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffo\Documents\OP Docs\Projects\electionapp\resources\views/poll/result_screen.blade.php ENDPATH**/ ?>