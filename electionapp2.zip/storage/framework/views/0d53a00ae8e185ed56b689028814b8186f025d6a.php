

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="h3 mb-2 text-gray-800">Poll Details</h1>
            <poll-details :poll="<?php echo e(json_encode($poll)); ?>"></poll-details>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffo\Documents\OP Docs\Projects\electionapp\resources\views/poll/show.blade.php ENDPATH**/ ?>